var searchData=
[
  ['insertnewmember',['insertNewMember',['../class_member_administration_1_1_database_helper.html#ab90d21d1ca121778edc4fe58dfe1bc04',1,'MemberAdministration::DatabaseHelper']]]
];
