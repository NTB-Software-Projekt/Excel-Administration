var searchData=
[
  ['state',['State',['../class_member_administration_1_1_person.html#a07f4f4036fca22aab8dbb54650668661',1,'MemberAdministration::Person']]],
  ['surname',['Surname',['../class_member_administration_1_1_person.html#a2c4df8f40e7c309d61ff2df63615e4e2',1,'MemberAdministration::Person']]]
];
