var searchData=
[
  ['databasehelper',['DatabaseHelper',['../class_member_administration_1_1_database_helper.html',1,'MemberAdministration']]]
];
