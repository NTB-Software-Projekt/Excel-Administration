var searchData=
[
  ['backupmanager',['BackupManager',['../class_member_administration_1_1_backup_manager.html',1,'MemberAdministration']]]
];
