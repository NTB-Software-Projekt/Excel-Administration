﻿namespace MemberAdministration
{
    partial class NewMember
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.paymentBox = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.mailBox = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.phoneBox = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.stateBox = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.zipBox = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.addressBox = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.nameBox = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.surnameBox = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.titleBox = new System.Windows.Forms.TextBox();
            this.cancelButton = new System.Windows.Forms.Button();
            this.addMemberButton = new System.Windows.Forms.Button();
            this.resetButton = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(42, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(30, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Title:";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.paymentBox);
            this.panel1.Controls.Add(this.label9);
            this.panel1.Controls.Add(this.mailBox);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.phoneBox);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.stateBox);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.zipBox);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.addressBox);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.nameBox);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.surnameBox);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.titleBox);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 12);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(335, 368);
            this.panel1.TabIndex = 1;
            // 
            // paymentBox
            // 
            this.paymentBox.Location = new System.Drawing.Point(130, 216);
            this.paymentBox.Name = "paymentBox";
            this.paymentBox.Size = new System.Drawing.Size(162, 20);
            this.paymentBox.TabIndex = 17;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(42, 219);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(90, 13);
            this.label9.TabIndex = 16;
            this.label9.Text = "Payment Amount:";
            // 
            // mailBox
            // 
            this.mailBox.Location = new System.Drawing.Point(130, 190);
            this.mailBox.Name = "mailBox";
            this.mailBox.Size = new System.Drawing.Size(162, 20);
            this.mailBox.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(42, 193);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(39, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "E-Mail:";
            // 
            // phoneBox
            // 
            this.phoneBox.Location = new System.Drawing.Point(130, 164);
            this.phoneBox.Name = "phoneBox";
            this.phoneBox.Size = new System.Drawing.Size(162, 20);
            this.phoneBox.TabIndex = 13;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(42, 167);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(41, 13);
            this.label7.TabIndex = 12;
            this.label7.Text = "Phone:";
            // 
            // stateBox
            // 
            this.stateBox.Location = new System.Drawing.Point(130, 138);
            this.stateBox.Name = "stateBox";
            this.stateBox.Size = new System.Drawing.Size(162, 20);
            this.stateBox.TabIndex = 11;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(42, 141);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(35, 13);
            this.label6.TabIndex = 10;
            this.label6.Text = "State:";
            // 
            // zipBox
            // 
            this.zipBox.Location = new System.Drawing.Point(130, 112);
            this.zipBox.Name = "zipBox";
            this.zipBox.Size = new System.Drawing.Size(162, 20);
            this.zipBox.TabIndex = 9;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(42, 115);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(53, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "Zip Code:";
            // 
            // addressBox
            // 
            this.addressBox.Location = new System.Drawing.Point(130, 86);
            this.addressBox.Name = "addressBox";
            this.addressBox.Size = new System.Drawing.Size(162, 20);
            this.addressBox.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(42, 89);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(48, 13);
            this.label4.TabIndex = 6;
            this.label4.Text = "Address:";
            // 
            // nameBox
            // 
            this.nameBox.Location = new System.Drawing.Point(130, 60);
            this.nameBox.Name = "nameBox";
            this.nameBox.Size = new System.Drawing.Size(162, 20);
            this.nameBox.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(42, 63);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(38, 13);
            this.label3.TabIndex = 4;
            this.label3.Text = "Name:";
            // 
            // surnameBox
            // 
            this.surnameBox.Location = new System.Drawing.Point(130, 34);
            this.surnameBox.Name = "surnameBox";
            this.surnameBox.Size = new System.Drawing.Size(162, 20);
            this.surnameBox.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(42, 37);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(52, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "Surname:";
            // 
            // titleBox
            // 
            this.titleBox.Location = new System.Drawing.Point(130, 8);
            this.titleBox.Name = "titleBox";
            this.titleBox.Size = new System.Drawing.Size(162, 20);
            this.titleBox.TabIndex = 1;
            // 
            // cancelButton
            // 
            this.cancelButton.Location = new System.Drawing.Point(272, 397);
            this.cancelButton.Name = "cancelButton";
            this.cancelButton.Size = new System.Drawing.Size(75, 23);
            this.cancelButton.TabIndex = 2;
            this.cancelButton.Text = "Cancel";
            this.cancelButton.UseVisualStyleBackColor = true;
            this.cancelButton.Click += new System.EventHandler(this.cancelButton_Click);
            // 
            // addMemberButton
            // 
            this.addMemberButton.Location = new System.Drawing.Point(22, 397);
            this.addMemberButton.Name = "addMemberButton";
            this.addMemberButton.Size = new System.Drawing.Size(123, 23);
            this.addMemberButton.TabIndex = 3;
            this.addMemberButton.Text = "Add Member";
            this.addMemberButton.UseVisualStyleBackColor = true;
            this.addMemberButton.Click += new System.EventHandler(this.addMemberButton_Click);
            // 
            // resetButton
            // 
            this.resetButton.Location = new System.Drawing.Point(191, 397);
            this.resetButton.Name = "resetButton";
            this.resetButton.Size = new System.Drawing.Size(75, 23);
            this.resetButton.TabIndex = 4;
            this.resetButton.Text = "Reset";
            this.resetButton.UseVisualStyleBackColor = true;
            this.resetButton.Click += new System.EventHandler(this.resetButton_Click);
            // 
            // NewMember
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(359, 451);
            this.Controls.Add(this.resetButton);
            this.Controls.Add(this.addMemberButton);
            this.Controls.Add(this.cancelButton);
            this.Controls.Add(this.panel1);
            this.MaximumSize = new System.Drawing.Size(367, 478);
            this.MinimumSize = new System.Drawing.Size(367, 478);
            this.Name = "NewMember";
            this.Text = "NewMember";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.TextBox stateBox;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox zipBox;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox addressBox;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox nameBox;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox surnameBox;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox titleBox;
        private System.Windows.Forms.Button cancelButton;
        private System.Windows.Forms.Button addMemberButton;
        private System.Windows.Forms.TextBox phoneBox;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox mailBox;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox paymentBox;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button resetButton;
    }
}